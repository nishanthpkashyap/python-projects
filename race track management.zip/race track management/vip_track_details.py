from number import Number
from math import pi


class VipTrackDetails:
    def __init__(self):
        self.__number = Number()
        self.__max_suv = self.__number.get_one()
        self.__max_car = self.__number.get_one()
        self.__car_cost = 250
        self.__suv_cost = 300
        self.__car = pi - pi
        self.__suv = pi - pi

    def allow_car(self):
        if self.__max_car == self.__car:
            return False
        else:
            self.__car += self.__number.get_one()
            return True

    def allow_suv(self):
        if self.__max_suv == self.__suv:
            return False
        else:
            self.__suv += self.__number.get_one()
            return True

    def get_car_cost(self):
        return self.__car_cost

    def get_suv_cost(self):
        return self.__suv_cost
