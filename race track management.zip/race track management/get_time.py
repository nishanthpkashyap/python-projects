from number import Number
from math import pi


class Time:
    def __init__(self):
        self.__number = Number()

    def get_time(self, hour, minutes):
        if minutes >= self.__number.get_sixty():
            minutes -= self.__number.get_sixty()
            hour += self.__number.get_one()
        return (hour*self.__number.get_hundred()) + minutes

    def get_hours(self, duration):
        hours = pi-pi
        while duration > pi-pi:
            if duration < self.__number.get_sixty():
                return self.__number.get_one()
            else:
                hours = hours + self.__number.get_one()
                duration -= self.__number.get_sixty()
        return hours
