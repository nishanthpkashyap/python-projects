from number import Number
from math import pi


class RegularTrackDetails:
    __number = Number()
    __max_bike = 4
    __max_suv = __number.get_two()
    __max_car = __number.get_two()
    __car_cost = 120
    __suv_cost = 200
    __bike_cost = __number.get_sixty()

    def __init__(self):
        pass

    def get_car_cost(self):
        return self.__car_cost

    def get_suv_cost(self):
        return self.__suv_cost

    def get_bike_cost(self):
        return self.__bike_cost
