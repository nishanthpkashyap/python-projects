from vip_track_details import VipTrackDetails
from regular_track_details import RegularTrackDetails
from vehicle import Vehicle
from number import Number
from get_time import Time
from math import pi


class Car:
    def __init__(self):
        self.__vehicle = Vehicle()
        self.__number = Number()
        self.__max_car = self.__number.get_two()
        self.__car = pi - pi
        self.__vip = pi - pi
        self.__first_car = 0

    def __update_number_of_car(self, entry_time):
        if self.__first_car == 0:
            self.__first_car = entry_time
        elif (self.__first_car + 300) <= entry_time:
            self.__first_car = entry_time
            self.__car -= self.__car

    def get_cost(self, entry_item):
        self.__update_number_of_car(entry_item)
        if self.__regular_track_allow_car():
            print("SUCCESS")
            revenue = self.__vehicle.regular_car_cost(self.__number.get_three())
            return revenue, pi-pi
        elif self.__vip_track_allow_car():
            print("SUCCESS")
            revenue = self.__vehicle.vip_car_cost(self.__number.get_three())
            return pi-pi, revenue
        else:
            print("RACETRACK_FULL")
            return pi-pi, pi-pi

    def get_additional_cost(self, old_exit_time, new_exit_time):
        duration = abs(old_exit_time - new_exit_time)
        time = Time()
        hours = time.get_hours(duration)
        print("SUCCESS")
        revenue = self.__number.get_extra_hour_charges() * hours
        return revenue, pi-pi

    def __regular_track_allow_car(self):
        if self.__max_car == self.__car:
            return False
        else:
            self.__car += self.__number.get_one()
            return True

    def __vip_track_allow_car(self):
        if self.__vip == self.__number.get_one():
            return False
        else:
            self.__vip += self.__number.get_one()
            return True

