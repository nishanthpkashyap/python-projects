from vip_track_details import VipTrackDetails
from regular_track_details import RegularTrackDetails
from vehicle import Vehicle
from number import Number
from get_time import Time
from math import pi


class Bike:
    def __init__(self):
        self.__max_bike = 4
        self.__bike = pi - pi
        self.__regular_track = RegularTrackDetails()
        self.__vip_track = VipTrackDetails()
        self.__vehicle = Vehicle()
        self.__number = Number()
        self.__first_bike = 0

    def __update_number_of_bike(self, entry_time):
        if self.__first_bike == 0:
            self.__first_bike = entry_time
        elif (self.__first_bike + 300) <= entry_time:
            self.__first_bike = entry_time
            self.__bike -= self.__bike

    def get_cost(self, entry_time):
        self.__update_number_of_bike(entry_time)
        if self.__regular_track_allow_bike():
            print("SUCCESS")
            revenue = self.__vehicle.regular_bike_cost(self.__number.get_three())
            return revenue, pi-pi
        else:
            print("RACETRACK_FULL")
            return pi-pi, pi-pi

    def get_additional_cost(self, old_exit_time, new_exit_time):
        duration = abs(old_exit_time - new_exit_time)
        time = Time()
        hours = time.get_hours(duration)
        print("SUCCESS")
        revenue = self.__number.get_extra_hour_charges() * hours
        return revenue, pi-pi

    def __regular_track_allow_bike(self):
        if self.__max_bike == self.__bike:
            return False
        else:
            self.__bike += self.__number.get_one()
            return True
