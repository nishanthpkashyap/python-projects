from sys import argv
from get_input import GetInput
from display_output import DisplayOutput
from number import Number


def main():
    number = Number()
    get_input = GetInput()
    if len(argv) != number.get_two():
        raise Exception("File path not entered")
    file_path = argv[1]
    f = open(file_path, 'r')
    lines = f.readlines()
    for i in lines:
        line = i.split(" ")
        if line[0] == "BOOK":
            get_input.add_book(line)
        elif line[0] == "ADDITIONAL":
            get_input.add_additional(line)
        elif line[0] == "REVENUE":
            commands = get_input.get_commands()
            display_output = DisplayOutput(commands)
            regular_revenue, vip_revenue = display_output.get_revenue()
            print(f'{round(regular_revenue)} {round(vip_revenue)}')


if __name__ == "__main__":
    main()
