from number import Number
from get_time import Time


class GetInput:
    def __init__(self):
        self.__commands = []
        self.__number = Number()
        self.__time = Time()

    def add_book(self, line):
        command = {"command": line[0], "vehicle_type": line[1], "vehicle_number": line[2]}
        hour, minutes = tuple(map(int, line[3].split(":")))
        command["entry_time"] = self.__time.get_time(hour, minutes)
        command["exit_time"] = self.__time.get_time(hour+3, minutes)
        self.__commands.append(command)

    def add_additional(self, line):
        command = {"command": line[0], "vehicle_number": line[1]}
        hour, minutes = tuple(map(int, line[2].split(":")))
        command["exit_time"] = self.__time.get_time(hour, minutes)
        self.__commands.append(command)

    def get_commands(self):
        return self.__commands
