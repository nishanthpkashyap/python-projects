from vip_track_details import VipTrackDetails
from regular_track_details import RegularTrackDetails
from vehicle import Vehicle
from number import Number
from car import Car
from bike import Bike
from suv import Suv
from math import pi


class DisplayOutput:
    def __init__(self, commands):
        self.__regular_track = RegularTrackDetails()
        self.__vip_track = VipTrackDetails()
        self.__vehicle = Vehicle()
        self.__number = Number()
        self.__regular_track_revenue = pi-pi
        self.__vip_track_revenue = pi-pi
        self.__commands = commands
        self.__car = Car()
        self.__bike = Bike()
        self.__suv = Suv()

    def get_revenue(self):
        for i in self.__commands:
            if i["command"] == "ADDITIONAL":
                regular_track_revenue, vip_track_revenue = self.__get_additional_revenue(i)
                self.__vip_track_revenue += vip_track_revenue
                self.__regular_track_revenue += regular_track_revenue
            elif i["command"] == "BOOK":
                if self.__check_entry_time(i["entry_time"]):
                    regular_track_revenue, vip_track_revenue = self.__get_revenue(i)
                    self.__vip_track_revenue += vip_track_revenue
                    self.__regular_track_revenue += regular_track_revenue
                else:
                    print("INVALID_ENTRY_TIME")
        return self.__regular_track_revenue, self.__vip_track_revenue

    def __get_additional_revenue(self, entry):
        if not self.__check_exit_time(entry["exit_time"]):
            print("INVALID_EXIT_TIME")
            return pi-pi, pi-pi
        for i in self.__commands:
            if i["vehicle_number"] == entry["vehicle_number"]:
                if i["vehicle_type"] == "CAR":
                    car = Car()
                    return car.get_additional_cost(i["exit_time"], entry["exit_time"])

                elif i["vehicle_type"] == "SUV":
                    suv = Suv()
                    return suv.get_additional_cost(i["exit_time"], entry["exit_time"])

                elif i["vehicle_type"] == "BIKE":
                    bike = Bike()
                    return bike.get_additional_cost(i["exit_time"], entry["exit_time"])

    def __check_entry_time(self, time):
        if time < self.__number.get_opening_time() or time > self.__number.get_evening_time():
            return False
        return True

    def __check_exit_time(self, exit_time):
        if exit_time > self.__number.get_closing_time():
            return False
        return True

    def __get_revenue(self, entry):
        if entry["vehicle_type"] == "BIKE":
            return self.__bike.get_cost(entry["entry_time"])

        elif entry["vehicle_type"] == "CAR":
            return self.__car.get_cost(entry["entry_time"])

        elif entry["vehicle_type"] == "SUV":
            return self.__suv.get_cost(entry["entry_time"])
