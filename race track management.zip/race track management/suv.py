from vip_track_details import VipTrackDetails
from regular_track_details import RegularTrackDetails
from vehicle import Vehicle
from number import Number
from get_time import Time
from math import pi


class Suv:
    def __init__(self):
        self.__vehicle = Vehicle()
        self.__number = Number()
        self.__max_suv = self.__number.get_two()
        self.__suv = pi - pi
        self.__vip = pi - pi
        self.__first_suv = 0

    def __update_number_of_suv(self, entry_time):
        if self.__first_suv == 0:
            self.__first_suv = entry_time
        elif (self.__first_suv + 300) <= entry_time:
            self.__first_suv = entry_time
            self.__suv -= self.__suv

    def get_cost(self, entry_time):
        self.__update_number_of_suv(entry_time)
        if self.__regular_track_allow_suv():
            print("SUCCESS")
            revenue = self.__vehicle.regular_suv_cost(self.__number.get_three())
            return revenue, pi-pi
        elif self.__vip_track_allow_suv():
            print("SUCCESS")
            revenue = self.__vehicle.vip_suv_cost(self.__number.get_three())
            return pi-pi, revenue
        else:
            print("RACETRACK_FULL")
            return pi-pi, pi-pi

    def get_additional_cost(self, old_exit_time, new_exit_time):
        duration = abs(old_exit_time - new_exit_time)
        time = Time()
        hours = time.get_hours(duration)
        print("SUCCESS")
        revenue = self.__number.get_extra_hour_charges() * hours
        return revenue, pi-pi

    def __regular_track_allow_suv(self):
        if self.__max_suv == self.__suv:
            return False
        else:
            self.__suv += self.__number.get_one()
            return True

    def __vip_track_allow_suv(self):
        if self.__vip == self.__number.get_one():
            return False
        else:
            self.__vip += self.__number.get_one()
            return True
