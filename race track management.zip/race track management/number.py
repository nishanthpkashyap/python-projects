class Number:
    def __init__(self):
        self.__one = 1
        self.__two = 2
        self.__three = 3
        self.__hundred = 100
        self.__sixty = 60
        self.__over_time = 315
        self.__closing_time = 2000
        self.__opening_time = 1300
        self.__evening_time = 1700
        self.__fifteen = 15
        self.__extra_hour_charges = 50

    def get_two(self):
        return self.__two

    def get_hundred(self):
        return self.__hundred

    def get_sixty(self):
        return self.__sixty

    def get_over_time_duration(self):
        return self.__over_time

    def get_one(self):
        return self.__one

    def get_three(self):
        return self.__three

    def get_evening_time(self):
        return self.__evening_time

    def get_opening_time(self):
        return self.__opening_time

    def get_closing_time(self):
        return self.__closing_time

    def get_extra_hour_charges(self):
        return self.__extra_hour_charges

    def get_fifteen(self):
        return self.__fifteen
