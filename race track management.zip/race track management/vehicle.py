from regular_track_details import RegularTrackDetails
from vip_track_details import VipTrackDetails


class Vehicle:
    def __init__(self):
        self.__regular_track = RegularTrackDetails()
        self.__vip_track = VipTrackDetails()

    def regular_car_cost(self, hours):
        car_cost = self.__regular_track.get_car_cost()
        return car_cost * hours

    def regular_suv_cost(self, hours):
        suv_cost = self.__regular_track.get_suv_cost()
        return suv_cost * hours

    def regular_bike_cost(self, hours):
        bike_cost = self.__regular_track.get_bike_cost()
        return bike_cost * hours

    def vip_car_cost(self, hours):
        car_cost = self.__vip_track.get_car_cost()
        return car_cost * hours

    def vip_suv_cost(self, hours):
        suv_cost = self.__vip_track.get_suv_cost()
        return suv_cost * hours
