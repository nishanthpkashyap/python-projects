from sys import argv
from validateDate import ValidateDate
from printBill import PrintBill


def main():
    is_date_valid = False
    print_bill = PrintBill()
    subscription = {}
    instruction = {}
    if len(argv) != 2:
        raise Exception("File path not entered")
    file_path = argv[1]
    f = open(file_path, 'r')
    lines = f.readlines()
    for line in lines:
        command = line.split(" ")
        if command[0] == "START_SUBSCRIPTION":
            is_date_valid = ValidateDate.validate_date(command[1][:len(command[1])-1])
            if is_date_valid:
                instruction[command[0]] = command[1]
            else:
                print("INVALID_DATE")

        elif command[0] == "ADD_SUBSCRIPTION":
            if is_date_valid:
                if command[1] in subscription.keys():
                    print("ADD_SUBSCRIPTION_FAILED DUPLICATE_CATEGORY")
                else:
                    subscription[command[1]] = command[2][:len(command[2])-1]
            else:
                print("ADD_SUBSCRIPTION_FAILED INVALID DATE")

        elif command[0] == "ADD_TOPUP":
            if "top_up" in instruction.keys():
                print("ADD_TOPUP_FAILED DUPLICATE_TOPUP")
            else:
                instruction["SUBSCRIPTIONS"] = subscription
                instruction["top_up_type"] = command[1]
                instruction["number_of_top_up"] = int(command[2][:len(command[2])-1])

        else:
            if "SUBSCRIPTIONS" in instruction.keys():
                print_bill.calculate_bill_amount(instruction)
            else:
                print("SUBSCRIPTIONS_NOT_FOUND")


if __name__ == "__main__":
    main()
