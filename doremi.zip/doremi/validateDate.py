class ValidateDate:
    @classmethod
    def validate_date(cls, date):
        day, month, year = tuple(map(int, date.split("-")))
        if 0 < day <= 31:
            if 1 <= month <= 12:
                return True

