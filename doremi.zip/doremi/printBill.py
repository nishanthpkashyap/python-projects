class PrintBill:
    def __init__(self):
        self.__renewal_amount = 0
        self.__plan_amount = {"MUSIC": {"PREMIUM": 250, "PERSONAL": 100},
                              "VIDEO": {"PREMIUM": 500, "PERSONAL": 200},
                              "PODCAST": {"PREMIUM": 100, "PERSONAL": 300}}

    def calculate_bill_amount(self, instructions):
        subscription = instructions["SUBSCRIPTIONS"]
        for key in subscription.keys():
            self.__update_renewal_amount(key, subscription[key])
            //self.__print_remainder_message(key, subscription[key], instructions["START_SUBSCRIPTION"])
        self.__top_up(instructions["top_up_type"], instructions["number_of_top_up"])
        self.__print_amount()

    def __top_up(self, number_of_devices, number_of_months):
        if number_of_devices=="FOUR_DEVICE":
            self.__renewal_amount += number_of_months*50
        else:
            self.__renewal_amount += number_of_months*100

    def __print_remainder_message(self, category, plan_name, date):
        renewal_date = date[:4]+str(int(date[4])+1)+date[5:]
        print(f'RENEWAL_REMAINDER {category} {renewal_date}')

    def __update_renewal_amount(self, category, plan_name):
        self.__renewal_amount += self.__plan_amount[category][plan_name]

    def __print_amount(self):
        print(f'RENEWAL_AMOUNT {self.__renewal_amount}')
